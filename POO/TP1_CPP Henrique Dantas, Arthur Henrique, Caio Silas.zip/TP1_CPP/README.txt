Diretiva de compilação pelo terminal do Linux:

$ g++ main.cpp Eletronico.cpp Impresso.cpp AudioBook.cpp Livro.cpp Functions.cpp -o tp
$ ./tp

Diretiva de compilação pelo terminal do Windowns:

> g++ main.cpp Eletronico.cpp Impresso.cpp AudioBook.cpp Livro.cpp Functions.cpp -o tp.exe
> tp.exe

