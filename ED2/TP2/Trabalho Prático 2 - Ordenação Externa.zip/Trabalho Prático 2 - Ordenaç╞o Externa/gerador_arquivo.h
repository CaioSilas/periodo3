#ifndef GERADOR_ARQUIVO_H
#define GERADOR_ARQUIVO_H

FILE* gerador_arquivo(int n, int tipo);

#endif//GERADOR_ARQUIVO_H

